CREATE DATABASE yoyo

use yoyo

CREATE TABLE SKUTable(
SKU NVARCHAR(8) PRIMARY KEY,
ProductDescription NVARCHAR(50),
Colour NVARCHAR(24)
)


CREATE TABLE ScheduleTable(
StartTime TIME,
EndTime TIME,
TheDate NVARCHAR(28),
SKUID NVARCHAR(8),
WorkArea NVARCHAR(50),
PRIMARY KEY(StartTime,TheDate),
FOREIGN KEY (SKUID) REFERENCES SKUTable(SKU)
)


CREATE TABLE RejectTable(
RejectID INT identity(1,1) PRIMARY KEY,
InspectionalLocation INT,
TypeOfAction NVARCHAR(50),
Reason NVARCHAR(50)
)


CREATE TABLE ProductionStateTable(
StateID INT identity(1,1) PRIMARY KEY,
TheState NVARCHAR(50), 
StateDescription NVARCHAR(50)
)


CREATE TABLE YoyoTable(
WorkArea NVARCHAR(50),
YoYoID NVARCHAR(128),
LineNumber NVARCHAR(8),
StateID INT,
RejectID INT,
DateTimeOfCompletion DATETIME,
SKUID NVARCHAR(8),
FOREIGN KEY (StateID) REFERENCES ProductionStateTable(StateID),
FOREIGN KEY (RejectID) REFERENCES rejectTable(RejectID),
FOREIGN KEY (SKUID) REFERENCES SKUTable(SKU)
)


CREATE TABLE UsersTable(
ID INT PRIMARY KEY,
Name NVARCHAR(50),
ThePassword NVARCHAR(128),
SecurityLevel INT
)



INSERT INTO SKUTable(SKU, ProductDescription, Colour)
SELECT 'Y001-1', 'Prestige Classic', 'Red'
UNION ALL
SELECT 'Y001-2', 'Prestige Classic', 'Blue'
UNION ALL
SELECT 'Y001-3', 'Prestige Classic', 'Green'
UNION ALL
SELECT 'Y002-0', 'Clear Plastic', 'Clear'
UNION ALL
SELECT 'Y005-1', 'Whistler', 'Red'
UNION ALL
SELECT 'Y005-2', 'Whistler', 'Blue'
UNION ALL
SELECT 'Y006-3', 'Whistler', 'Green'




INSERT INTO ProductionStateTable(TheState, StateDescription)
SELECT 'MOLD', 'In the Mold process'
UNION ALL
SELECT 'QUEUE_INSPECTION_1', 'On the conveyor to inspection station 1'
UNION ALL
SELECT 'INSPECTION_1', 'At inspection station 1'
UNION ALL
SELECT 'INSPECTION_1_SCRAP', 'In scrap (end of process for that particular yoyo)'
UNION ALL
SELECT 'QUEUE_PAINT', 'On the conveyor to the paint process'
UNION ALL
SELECT 'PAINT', 'In the paint process'
UNION ALL
SELECT 'QUEUE_INSPECTION_2', 'On the cinveyor to inspection station 2'
UNION ALL
SELECT 'INSPECTION_2', 'At inspection station 2'
UNION ALL
SELECT 'INSPECTION_2_REWORK', 'Being reworked and sent back to paint'
UNION ALL
SELECT 'INSPECTION_2_SCRAP', 'In scrap (end of process for that particular yoyo)'
UNION ALL
SELECT 'QUEUE_ASSEMBLY', 'On the conveyor to the assembly process'
UNION ALL
SELECT 'ASSEMBLY', 'In the assembly process'
UNION ALL
SELECT 'QUEUE_INSEOCTION_3', 'On the conveyor to inspection station 3'
UNION ALL
SELECT 'INSPECTION_3', 'At inspection station 3'
UNION ALL
SELECT 'INSPECTION_3_REWORK', 'Being reworked and sent back to assembly'
UNION ALL
SELECT 'INSPECTION_3_SCRAP', 'In scrap (end of process for that particular yoyo)'
UNION ALL
SELECT 'PACKAGE', 'In package (end of process for a good yoyo)'






INSERT INTO RejectTable(InspectionalLocation, TypeOfAction, Reason)
SELECT 1, 'Reject', 'Inconsistent thickness'
UNION ALL
SELECT 1, 'Reject', 'Pitting'
UNION ALL
SELECT 1, 'Reject', 'Wraping'
UNION ALL
SELECT 2, 'Reject', 'Primer Defect'
UNION ALL
SELECT 2, 'Rework', 'Drip mark'
UNION ALL
SELECT 2, 'Rework', 'Final Coat flaw'
UNION ALL
SELECT 3, 'Reject', 'Broken shell'
UNION ALL
SELECT 3, 'Rework', 'Broken Axle'
UNION ALL
SELECT 3, 'Rework', 'Tangled String'
UNION ALL
SELECT 3, 'Rework', 'Final Coat flaw'


SELECT * FROM RejectTable 
SELECT * FROM ProductionStateTable 
SELECT * FROM SKUTable 